/* eslint-disable */

import { HiX } from "react-icons/hi"; 
import { Link } from "react-router-dom"; 
import { BsFillBuildingFill } from "react-icons/bs";
import {SiMaterialdesignicons} from 'react-icons/si'
import {GiCargoCrane} from 'react-icons/gi'
import {useAuthStore} from 'App'
import { useTranslation } from "react-i18next";
import { useLanguageStore } from "App";


import logoImg from '../../assets/img/logo.png';

const Sidebar = ({ open, onClose }) => {

  const { t} = useTranslation();

  const logout = useAuthStore((state) => state.logout);

  const language = useLanguageStore(state=>state.language)

  return (
    <div
      className={`sm:none duration-175 linear fixed !z-50 flex min-h-full flex-col bg-white pb-10 shadow-2xl shadow-white/5 transition-all dark:!bg-navy-800 dark:text-white md:!z-50 lg:!z-50 xl:!z-0 ${language === 'en' && open ? 'translate-x-0' : language === 'en' && !open ? '-translate-x-96' : ''}
      ${language !== 'en' &&  open ? '-translate-x-0' : language !== 'en' && !open ? 'translate-x-96' : ''}
      `}
    >
      <span
        className="absolute top-4 right-4 block cursor-pointer xl:hidden"
        onClick={onClose}
      >
        <HiX />
      </span>

      <div className={`mx-[56px]   flex items-center`}>
        <Link to='/' className="mt-1 ml-1 h-fit font-nunito text-[26px] font-bold uppercase text-navy-700 dark:text-white">
        <img src={logoImg} alt="Z Tower" className="w-[100px]"/>
        </Link>
      </div>
      <div class="mb-7 h-px bg-gray-300 dark:bg-white/30" />
      
      <ul className="mb-auto pt-1">
        <Link to='/'>
            <div className="relative mb-3 flex hover:cursor-pointer flex-col">
              <li
                className="my-[3px] flex cursor-pointer items-center w-full gap-8   px-8"
              >
                <span
                  className="
                   font-bold text-brand-500 dark:text-white
                  "
                >
                  <BsFillBuildingFill />
                </span>
                <p
                  className= "font-bold text-navy-700 dark:text-white mt-1"
                >
                {t("sidebarLinks.buildings")}
                </p>
                
              </li>
              <Link to='/needs'
                className="my-[3px] flex cursor-pointer items-center w-full gap-8   px-8"
              >
                <span
                  className="
                   font-bold text-brand-500 dark:text-white
                  "
                >
                  <GiCargoCrane />
                </span>
                <p
                  className= "font-bold text-navy-700 dark:text-white mt-1"
                >
                {t("sidebarLinks.needs")}
                </p>
                
              </Link>
              <Link to='/items'
                className="my-[3px] flex cursor-pointer items-center w-full gap-8   px-8"
              >
                <span
                  className="
                   font-bold text-brand-500 dark:text-white
                  "
                >
                  <SiMaterialdesignicons />
                </span>
                <p
                  className= "font-bold text-navy-700 dark:text-white mt-1"
                >
                 {t("sidebarLinks.items")}
                </p>
              </Link>
              
            </div>
          </Link>
          
      </ul>

      <button onClick={logout} className="border border-indigo-700 rounded-md w-fit mx-auto px-2 py-1 hover:bg-indigo-700 transition-colors duration-200 ease-linear hover:text-white">{t('logout')}</button>


    </div>
  );
};

export default Sidebar;
