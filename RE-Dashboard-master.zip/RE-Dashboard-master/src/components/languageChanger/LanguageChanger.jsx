import { useLanguageStore } from 'App';
import React, { useEffect, useRef, useState } from 'react'
import { IoLanguage } from 'react-icons/io5'

export default function LanguageChanger() {


  const [dropDown, setDropDown] = useState(false)
  const languageRef = useRef(null);

    const changeLanguage = useLanguageStore((state) => state.changeLanguage);
    const language = useLanguageStore((state) => state.language);
    
    const handleLanguageChange = (lang)=>{
      changeLanguage(lang)
    }
    

    const showLanguagesHandler = ()=>{
      setDropDown(!dropDown)
    }

    const handleOutsideClick = (e) => {
      if (languageRef.current && !languageRef.current.contains(e.target)) {
        setDropDown(false);
      }
    };

    useEffect(() => {
      document.addEventListener('click', handleOutsideClick);
  
      return () => {
        document.removeEventListener('click', handleOutsideClick);
      };
    }, []);

  return (
    <div
    className="relative cursor-pointer text-gray-600 px-2 leading-none"
  >
   <button onClick={showLanguagesHandler} ref={languageRef}>
        <IoLanguage/>          
   </button>

   {dropDown &&  <div className={`absolute ${language === 'en' ? 'right-0' : 'left-0'} top-6 py-4 px-6 bg-indigo-100 text-indigo-900 rounded-md  flex-col gap-2`}>

<button className="py-1 px-3 hover:bg-indigo-400 rounded-sm" onClick={()=>handleLanguageChange('en')}>English</button>
<button className="py-1 px-3 hover:bg-indigo-400 rounded-sm" onClick={()=>handleLanguageChange('ku')}>Kurdish</button>
<button className="py-1 px-3 hover:bg-indigo-400 rounded-sm" onClick={()=>handleLanguageChange('ar')}>Arabic</button>
</div>
}

  </div>
  )
}
